package app.src.entitas

class Guru{
    //atribute
   var nama:String ="Fareza Restu"
   var mapel:String="Produktif RPL"
   var alamat:String="Bandung"
    //method
    fun perkenalan(){
        println("Halo anak-anak!, nama saya "+ nama)
        println("saya dari, "+ alamat)
        println("Saya mengampu Mapel" + mapel)
    }

        fun quots(quots:String){
            println("Sebuah quots Dari Saya\n" + quots)
        }

    }

