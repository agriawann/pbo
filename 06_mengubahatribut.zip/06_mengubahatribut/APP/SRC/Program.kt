package app.src.entitas
import app.src.entitas.Guru

fun main(){
    println("-----------------------------------------")
    println("Lat. mengubah atribut: Fareza Restu")
    println("-----------------------------------------")

   
    var objek_guru = Guru()

    objek_guru.perkenalan()
    objek_guru.quots("Jadilah orang yang soleh")

    println("\nNama : "+ objek_guru.nama)
    println("Mapel : "+ objek_guru.mapel)
    println("Alamat : "+ objek_guru.alamat)

    //mengubah atribut
    objek_guru.nama = "wahyu"
    objek_guru.mapel = "Produktif TKJ"
    objek_guru.alamat = "Cirebon"
    objek_guru.perkenalan()

    //memanggil atribut
    println("\nNama : "+ objek_guru.nama)
    println("Mapel : "+ objek_guru.mapel)
    println("Alamat : "+ objek_guru.alamat)
}