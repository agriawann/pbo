package app.src
import app.src.entitas.Orang

fun main(){

    println("-------------------------------------")
    println("Lat. Multi Secondary Constructor : Fareza Restu")
    println("-------------------------------------")

    val rendy = Orang("Rendy", 12, "Pelajar")
    val alya = Orang("Alya", 12, "Pelajar")

    val amanda = Orang("Amanda", 20, "Customer Service", 3_000_000)
    val tira = Orang("Tira", 12, "Teller", 5_000_000)

}

