package app.src
import app.src.entitas.Manusia

fun main(){

    println("---------------------------")
    println("Lat. Nilai Dasar Pada Constructor : fareza restu")
    println("---------------------------")
    

    val manusia2 = Manusia("ronaldo", 17)
    val manusia1 = Manusia("fareza restu")
    
}

