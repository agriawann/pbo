package app.src.entitas

class Manusia (val  _nama: String, val _usia : Int=20) {
        var nama = _nama
        var usia = _usia

    init{
        this.nama = _nama
        this.usia = _usia

        println("Nama : $nama")
        println("Usia : $usia\n")
        
    }    

}