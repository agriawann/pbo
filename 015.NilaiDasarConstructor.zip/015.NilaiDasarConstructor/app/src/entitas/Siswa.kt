package app.src.entitas

class Siswa constructor(val nama:String, val kelas:String, val alamat:String){


fun infoSiswa(){
    println("~ Info Siswa ~")
    println("Nama : "+nama)
    println("Kelas : "+kelas)
    println("Alamat : "+alamat)
    }
}