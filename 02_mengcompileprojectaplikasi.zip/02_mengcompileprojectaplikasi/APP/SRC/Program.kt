package app.src

fun main(){
    println("-----------------------------------------")
    println("Lat. Mengcompile Project Aplikasi : Fareza")
    println("-----------------------------------------")
}