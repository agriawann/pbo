package app.src.entitas


open class Kucing{
    open fun infoMakan(){
        println("Dapat memakan Daging")
    }
}