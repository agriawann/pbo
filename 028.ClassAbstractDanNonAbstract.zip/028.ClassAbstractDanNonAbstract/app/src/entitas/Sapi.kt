package app.src.entitas

interface Sapi{ 
   fun infoMakan(){
        println("Dapat memakan tumbuhan")
    }
}
