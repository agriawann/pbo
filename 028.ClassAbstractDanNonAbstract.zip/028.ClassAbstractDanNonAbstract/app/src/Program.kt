package app.src.entitas
import app.src.entitas.Karyawan

fun main(){

    println("-------------------------------------")
    println("Lat. Class Abstract Dan Non Abstract : Fareza Restu")
    println("-------------------------------------")

   val ahmad = Karyawan("Ronaldo")
   var usia : Int


   ahmad.setOrangUsia(22)

   usia = ahmad.getOrangUsia()
   ahmad.getOrangNama()

   println("usia : $usia")

}

