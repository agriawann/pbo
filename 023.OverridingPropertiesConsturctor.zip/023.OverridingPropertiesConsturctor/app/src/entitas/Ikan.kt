package app.src.entitas
import app.src.entitas.Burung

    class Ikan(override val nama: String = "Lele"): Burung(){

     override fun info() {
            println("Saya adalah seekor ikan $nama")
        }
    }
