package app.src
import app.src.entitas.Ikan

fun main(){

    println("-------------------------------------")
    println("Lat. Overriding Propperties Constructor : Fareza Restu")
    println("-------------------------------------")

    val ikan = Ikan()
    ikan.info()

}

