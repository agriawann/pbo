package app.src
import app.src.entitas.*

fun main(){
    println("-----------------------------------------")
    println("Lat. Inner class (class didalam class) : Fareza")
    println("-----------------------------------------")
   
    val kelasLuar = Utama()
    val kelasDalam = Utama().Dalam()

    println( kelasLuar.menyapa() )
    println( kelasDalam.menyapa() )

}
