package app.src.entitas

class Utama {
    var massage="Hallo"
    fun menyapa() = "$massage , ini adalah fungsi adalam class utama"

    inner class Dalam {
        fun menyapa() = "$massage , dan ini adalah fungsi dari class didalam class"
    }

}
