package app.src

fun main(){
    println("-----------------------------------------")
    println("Lat. membuat class : Fareza")
    println("-----------------------------------------")
}