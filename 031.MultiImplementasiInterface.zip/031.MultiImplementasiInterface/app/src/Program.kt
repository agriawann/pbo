package app.src.entitas
import app.src.entitas.Ikan
import app.src.entitas.Jerapah

fun main(){

    println("-------------------------------------")
    println("Lat. Multi Implementasi Interface : Fareza Restu")
    println("-------------------------------------")

    var objek = Implementasi()

    objek.menyapaDariInterfaceA()
    objek.menyapaDariInterfaceB()
    objek.menyapaDariInterfaceC()
    objek.menyapaDariInterfaceD()
}

  

