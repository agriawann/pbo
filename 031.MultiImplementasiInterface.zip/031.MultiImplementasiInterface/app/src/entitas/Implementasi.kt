package app.src.entitas
import app.src.entitas.*

class Implementasi:InterFaceA, InterFaceB, InterFaceC, InterFaceD {
    
}