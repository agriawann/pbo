package app.src.entitas

interface InterFaceA{
    fun menyapaDariInterfaceA(){
        println("Method ini implementasi dari interface A")
    }
}