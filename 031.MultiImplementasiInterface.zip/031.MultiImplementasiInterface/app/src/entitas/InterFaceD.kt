package app.src.entitas

interface InterFaceD{
    fun menyapaDariInterfaceD(){
        println("Method ini implementasi dari interface D")
    }
}