package app.src.entitas

interface InterFaceB{
    fun menyapaDariInterfaceB(){
        println("Method ini implementasi dari interface B")
    }
}