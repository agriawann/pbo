package app.src.entitas
import app.src.entitas.MahlukHidup

class Manusia: MahlukHidup{
    override var nama_mahluk: String = "Novi"
    override var habitat: String = "Darat"

    override fun jenis_makanan(): String = "Omnivora"
    override fun info(){
        println("Nama Manusia adalah: $nama_mahluk")
        println("Habitat / Tempat Tinggal : $habitat")
        println("Jenis Makanan : ${jenis_makanan()}")
    }
}