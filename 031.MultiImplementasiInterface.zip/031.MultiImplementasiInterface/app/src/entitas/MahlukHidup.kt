package app.src.entitas

interface MahlukHidup{
    var nama_mahluk: String
    var habitat: String

    fun jenis_makanan():String
    fun info()
}