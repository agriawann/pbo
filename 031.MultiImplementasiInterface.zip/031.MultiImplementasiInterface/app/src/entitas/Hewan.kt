package app.src.entitas

interface Hewan{
    var nama:String

    fun makan()

    fun infoHewan()="nama hewan $nama"
}