package app.src.entitas

interface InterFaceC{
    fun menyapaDariInterfaceC(){
        println("Method ini implementasi dari interface C")
    }
}