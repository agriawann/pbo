package app.src
import app.src.entitas.Adik

fun main(){

    println("-------------------------------------")
    println("Lat. Inisialisasi Class Turunan : Fareza Restu")
    println("-------------------------------------")

    val fikri = Adik()

}

