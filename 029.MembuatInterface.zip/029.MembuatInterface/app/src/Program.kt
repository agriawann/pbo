package app.src.entitas
import app.src.entitas.Ikan
import app.src.entitas.Jerapah

fun main(){

    println("-------------------------------------")
    println("Lat. Membuat Interface : Fareza Restu")
    println("-------------------------------------")

   val ikan1 = Ikan()
   ikan1.makan()
   println(ikan1.infoHewan())
   ikan1.nama= "Ikan Buyur"
   println("Ikan baru : ${ikan1.infoHewan()}")

   println("---------------------------------------")

   val jerapah1 = Jerapah()
   jerapah1.makan()
   println(jerapah1.infoHewan())
   jerapah1.nama = "Jerapah Amazon"
   println("Jerapah baru : ${jerapah1.infoHewan()}")
}

