package app.src.entitas
import app.src.entitas.Orang

class Karyawan(_nama: String):Orang(_nama) {
    override var usia: Int = 0

    override fun setOrangUsia(_usia: Int) {
        usia = _usia
    }
    override fun getOrangUsia():Int {
        return usia

    }
}