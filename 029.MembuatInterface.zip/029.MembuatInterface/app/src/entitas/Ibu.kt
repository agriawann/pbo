package app.src.entitas

open class Ibu{
    init{
        println("Ibu suka makan tahu bulat!")
    }
}