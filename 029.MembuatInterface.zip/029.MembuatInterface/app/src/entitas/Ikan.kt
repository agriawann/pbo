package app.src.entitas

class Ikan: Hewan {
    override var nama: String = "Ikan Cupang"

    override fun makan(){
        println("Ikan cupang memakan pelet")
    }
}