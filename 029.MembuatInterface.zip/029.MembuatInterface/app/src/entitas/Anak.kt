package app.src.entitas
import app.src.entitas.Ayah

class Anak(override val nama:String="Novi"):Ayah(){
    override fun perkenalan(){
        println("Saya adalah seorang anak")

        println("Saya anak dari ayah" + super.nama)
        super.makananFavorit()
    }

    override fun makananFavorit(){
        println(this.nama + "Suka makan ketoprak")
    }
}