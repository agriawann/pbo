package app.src.entitas
import app.src.entitas.Pegawai

fun main(){

    println("-------------------------------------")
    println("Lat. Membuat Class Abstract : Fareza Restu")
    println("-------------------------------------")

    val pegawai = Pegawai()

    pegawai.setNamaOrang("Ronaldo")
    pegawai.setUsiaOrang(20)
    pegawai.setPekerjaanOrang("Staff TU")

    println("Nama : " + pegawai.gerNamaOrang())
    println("Usia : " + pegawai.getUsiaOrang())
    println("Pekerjaan : " + pegawai.getPekerjaanOrang())

}

