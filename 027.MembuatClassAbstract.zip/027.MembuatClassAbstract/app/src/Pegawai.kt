package app.src.entitas
import app.src.entitas.Orang

class Pegawai:Orang(){
    override var nama:String = ""
    override var usia:Int = 0
    override var pekerjaan:String = ""

    override fun setUsiaOrang(_usia:Int){usia=_usia}
    override fun setNamaOrang(_nama:String){nama=_nama}
    override fun setPekerjaanOrang(_pekerjaan:String){pekerjaan=_pekerjaan}

    override fun getUsiaOrang():Int= usia
    override fun gerNamaOrang():String= nama
    override fun getPekerjaanOrang():String= pekerjaan
}