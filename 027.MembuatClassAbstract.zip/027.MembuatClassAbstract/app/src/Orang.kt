package app.src.entitas

abstract class Orang{
    abstract var nama:String
    abstract var usia:Int
    abstract var pekerjaan:String


    abstract fun setUsiaOrang(_usia:Int)
    abstract fun getUsiaOrang():Int

    abstract fun setNamaOrang(_nama:String)
    abstract fun gerNamaOrang():String

    abstract fun setPekerjaanOrang(_pekerjaan:String)
    abstract fun getPekerjaanOrang():String
}