package app.src.entitas

open class Burung{
    open val nama: String = "Merpati"

    open fun info(){
        println("Hey!! Saya adalah seekor Burung" + this.nama)
    }
}