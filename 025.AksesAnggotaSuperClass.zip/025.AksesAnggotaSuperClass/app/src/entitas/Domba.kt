package app.src.entitas

open class Domba{
    final fun bernafas(){
        println("Binatang bernafas!")
    }

    open fun makan(){
        println("Domba, Sedang Makan Rumput")
    }
}