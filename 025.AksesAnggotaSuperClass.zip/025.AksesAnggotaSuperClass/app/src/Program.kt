package app.src
import app.src.entitas.Anak

fun main(){

    println("-------------------------------------")
    println("Lat. Akses Anggota Super Class : Fareza Restu")
    println("-------------------------------------")

    val mila = Anak()
    mila.perkenalan()
    mila.makananFavorit()

}

