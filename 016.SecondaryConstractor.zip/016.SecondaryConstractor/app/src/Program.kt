package app.src
import app.src.entitas.Siswa

fun main(){

    println("-------------------------------------")
    println("Lat. Secondary Constructor : Fareza Restu")
    println("-------------------------------------")

    //membuat objek disertai konstruktor
    val restu = Siswa("Restu", 17)

}

