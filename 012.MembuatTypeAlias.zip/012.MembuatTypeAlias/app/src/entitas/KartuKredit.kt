package app.src.entitas

typealias Kartu = String
typealias Pin = Int

class KartuKredit {
    fun namaKartu (card:Kartu){
        println("Nama Kartu : "+card)
    }

    fun password(card:Pin) {
        println("Pin Kartu : "+card)
    }
}