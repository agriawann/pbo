package app.src
import app.src.entitas.KartuKredit

typealias KartuAtm = KartuKredit

fun main(){
    println("-----------------------------------")
    println("Lat. Membuat Type Alias : Fareza Restu")
    println("-----------------------------------")

    var kartu = KartuAtm()

    kartu.namaKartu("BRI")
    kartu.password(123456)
}
