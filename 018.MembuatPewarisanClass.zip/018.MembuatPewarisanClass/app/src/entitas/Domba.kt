package app.src.entitas

open class Domba{
    fun makan(){
        println("Sedang makan")
    }
}