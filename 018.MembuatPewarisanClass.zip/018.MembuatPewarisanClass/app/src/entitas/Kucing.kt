package app.src.entitas
import app.src.entitas.Domba

class Kucing:Domba(){
    
}