package app.src.entitas
import app.src.entitas.Ikan
import app.src.entitas.Jerapah

fun main(){

    println("-------------------------------------")
    println("Lat. Implementasi Interface : Fareza Restu")
    println("-------------------------------------")

    var manusia = Manusia()
    var hewan = Onta()

    manusia.info()
    hewan.info()
}

  

