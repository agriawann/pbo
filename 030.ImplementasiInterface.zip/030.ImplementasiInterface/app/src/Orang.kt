package app.src.entitas

abstract class Orang(_nama: String){
    var nama: String
    abstract var usia : Int

    init {
        this.nama = _nama
    }

    abstract fun setOrangUsia(_usia:Int)
    abstract fun getOrangUsia():Int

    fun getOrangNama(){
        println("Nama : $nama")
    }
}