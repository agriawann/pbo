package app.src.entitas
import app.src.entitas.Ibu

open class Kaka:Ibu(){
    init{
        println("Kaka suka minum Boba!")
    }
}