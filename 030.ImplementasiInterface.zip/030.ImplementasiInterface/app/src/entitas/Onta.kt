package app.src.entitas
import app.src.entitas.MahlukHidup

class Onta: MahlukHidup{
    override var nama_mahluk: String = "Onta Jantan"
    override var habitat: String = "Darat"

    override fun jenis_makanan():String = "Herbivora"
    override fun info(){
        println("Nama Hewan adalah : $nama_mahluk")
        println("Habitat / Tempat Tinggal : $habitat")
        println("Jenis Makanan : ${jenis_makanan()}")
        println("-------------------------------------")

    }
}