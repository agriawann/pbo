package app.src.entitas

class Jerapah: Hewan{
    override var nama: String = "Jerapah aprika"

    override fun makan(){
        println("Jerapah memakan daun dan rumput")
    }
}