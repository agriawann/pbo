package app.src.entitas

open class Ayah{
    open val nama:String

    init{
        nama = "Budi"
    }

    open fun perkenalan(){
        println("Saya adalag seorang ayah")
    }

    open fun makananFavorit(){
        println("Ayah $nama Suka makan burger")
    }
}