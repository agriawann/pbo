package app.src.entitas
import app.src.entitas.Burung

class Ikan: Burung() {
    override val nama: String

    init{
        nama = "Lele"

    }
        override fun info() {
            println("Saya adalah seekor ikan " + (this.nama))
        }
}