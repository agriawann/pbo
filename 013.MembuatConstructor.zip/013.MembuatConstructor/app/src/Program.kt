package app.src
import app.src.entitas.*

fun main(){
    println("---------------------------")
    println("Lat. Membuat Constructor : fareza restu")
    println("---------------------------")

    val guru1 = Guru("Ujang Rudini", "Produktif RPL", "uzang.rudini@gmail.com")
    val guru2 = Guru("Tira Nur Indah", "Produktif MM", "tira.nur.indah@gmail.com")
    val guru3 = Guru("Fajar Oktafian", "Produktif TKJ", "fajarokta@gmail.com")


    val siswa1 = Siswa("Oasa", "XI RPL", "Bandung")
    val siswa2 = Siswa("Azmi", "XI RPL", "Bali")
    val siswa3 = Siswa("Rendy", "XI RPL", "Batam")

    guru1.infoGuru()
    guru2.infoGuru()
    guru3.infoGuru()

    siswa1.infoSiswa()
    siswa2.infoSiswa()
    siswa3.infoSiswa()
}