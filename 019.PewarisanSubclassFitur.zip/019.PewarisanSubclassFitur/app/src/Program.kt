package app.src
import app.src.entitas.Kucing

fun main(){

    println("-------------------------------------")
    println("Lat. Membuat Pewarisan Class :Fareza Restu")
    println("-------------------------------------")

val kucing = Kucing()

kucing.makan()

kucing.memanjat("Goby")

}

