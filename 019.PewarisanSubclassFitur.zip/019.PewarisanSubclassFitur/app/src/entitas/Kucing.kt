package app.src.entitas
import app.src.entitas.Domba

class Kucing:Domba(){
    
    fun memanjat(nama: String){
        println("Kucing $nama Memanjat Pohon")
    }
}