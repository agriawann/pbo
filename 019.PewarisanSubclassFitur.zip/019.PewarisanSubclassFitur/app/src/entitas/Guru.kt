package app.src.entitas

class Guru constructor(val nama:String, val mapel:String, val email:String){

fun infoGuru(){
    println("~ Info Guru ~")
    println("Nama : "+nama)
    println("Mapel : "+mapel)
    println("E-mail : "+email)
    }
}