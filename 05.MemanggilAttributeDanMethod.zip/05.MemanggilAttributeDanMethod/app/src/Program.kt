package app.src
import app.src.entitas.Guru

fun main(){
    println("-------------------------------------------------")
    println("Lat.Memanggil atribut dan method : Fareza Restu")
    println("-------------------------------------------------")


    var objek_guru = Guru()

    objek_guru.perkenalan()
    objek_guru.quots("Jadilah orang yang salah")

    println("\nNama : "+ objek_guru.nama)
    println("\nMapel :"+ objek_guru.mapel)
    println("\nAlamat :"+ objek_guru.alamat)

}