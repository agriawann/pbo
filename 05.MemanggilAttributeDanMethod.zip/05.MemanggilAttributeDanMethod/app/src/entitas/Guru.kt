package app.src.entitas

class Guru {
    var nama:String = "Fareza Restu"
    var mapel:String = "Pruduktif RPL"
    var alamat:String = "Ciparay"


    fun perkenalan(){
        println("Halo Anak-Anak, nama saya" + nama)
        println("Saya dari," + alamat)
        println("Saya Mengampu Mapel," + mapel)
    }

    fun quots(quots:String){
        println("Sebuah Quots Dari Saya\n" + quots)
    }
}