package app.src

fun main(){
    println("-----------------------------------------")
    println("Lat. Menggunakan Triple case : Fareza")
    println("-----------------------------------------")


var triple = Triple("Fareza Restu", "Laki-laki", "Bandung")

println("Nama : "+ triple.first)
println("Jenis Kelamin : "+ triple.second)
println("Alamat : "+ triple.third )

println("-----------")

val (x, y, z) = Triple(7, "Cristiano Ronaldo", "Lisbon")

println("No : "+ x)
println("Nama : "+ y)
println("Alamat : "+ z)

}
