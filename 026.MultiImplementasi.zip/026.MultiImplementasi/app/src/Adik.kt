package app.src.entitas
import app.src.entitas.Kaka

class Adik:Kaka(){
    init{
        println("Adik suka makan Ice Cream!")
    }
}