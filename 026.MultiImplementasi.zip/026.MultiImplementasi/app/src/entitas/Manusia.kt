package app.src.entitas

class Manusia:Kucing(), Sapi{

    override fun infoMakan(){
        super<Kucing>.infoMakan()
        super<Sapi>.infoMakan()
    }
}