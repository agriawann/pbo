package app.src
import app.src.entitas.Manusia

fun main(){

    println("-------------------------------------")
    println("Lat. Multi Implementasi : Fareza Restu")
    println("-------------------------------------")

   val wahyu = Manusia()
   wahyu.infoMakan()

}

