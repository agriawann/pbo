package app.src
import app.src.entitas.Kucing

fun main(){

    println("-------------------------------------")
    println("Lat. Overriding Method : Fareza Restu")
    println("-------------------------------------")

val kucing = Kucing()

kucing.bernafas()

kucing.makan()

}

