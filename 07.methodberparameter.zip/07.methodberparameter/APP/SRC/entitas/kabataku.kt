package app.src.entitas

class kabataku{
    fun jumlahkan(nilai1:Int, nilai2:Int) = (nilai1+nilai2)
    fun kalikan(nilai1:Int, nilai2:Int) = (nilai1*nilai2)
    fun bagi(nilai1:Int, nilai2:Int) = (nilai1/nilai2)
    fun kurangi(nilai1:Int, nilai2:Int) = (nilai1-nilai2)
}