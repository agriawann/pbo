package app.src
import app.src.entitas.kabataku

fun main(){
    println("-----------------------------------------")
    println("Lat. Method Berparameter : Fareza")
    println("-----------------------------------------")
    val nilai1=10
    val nilai2=10

   var kalkulator=kabataku()

     println("$nilai1 + $nilai2 = "+ kalkulator.jumlahkan(nilai1,nilai2))
     println("$nilai1 * $nilai2 = "+ kalkulator.kalikan(nilai1,nilai2))
     println("$nilai1 / $nilai2 = "+ kalkulator.bagi(nilai1,nilai2))
     println("$nilai1 - $nilai2 = "+ kalkulator.kurangi(nilai1,nilai2))
}
