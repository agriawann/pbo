package app.src
import app.src.entitas.Guru

fun main(){
    println("-----------------------------------------")
    println("Lat. membuat objek : Fareza")
    println("-----------------------------------------")

    //Ini adalah instansisa objek dari class guru
    //atau pembuatan objek
    var objek_guru = Guru()

    println(objek_guru)
}