package app.src.entitas

class Guru{
    //atribute
    private var nama:String = "Fareza Restu"

    //method
    fun perkenalan(){
        println("Halo anak-anak!, nama saya "+ nama)
    }
}