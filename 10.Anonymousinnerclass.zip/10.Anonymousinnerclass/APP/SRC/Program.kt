package app.src
import app.src.entitas.Siswa

fun main(){
    println("-----------------------------------------")
    println("Lat. Membuat Anonymous Inner Class : Fareza")
    println("-----------------------------------------")
   
    var fareza :Siswa = object:Siswa {
        override fun quote() {
            println("Fareza: Manfaatkan waktu, tetap belajar, tetap semangat!")

        }
    }
    var abdul :Siswa = object:Siswa {
        override fun quote() {
            println("Abdul: Jangan lupa ber do'a, disetiap aktivitasmu")
        }
}
fareza.quote()
abdul.quote()
}