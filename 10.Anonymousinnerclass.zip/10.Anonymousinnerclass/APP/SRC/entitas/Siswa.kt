package app.src.entitas

interface Siswa {
    fun quote()


}
