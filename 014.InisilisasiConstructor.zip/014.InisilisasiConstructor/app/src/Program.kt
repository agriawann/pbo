package app.src
import app.src.entitas.Kucing

fun main(){
    println("---------------------------")
    println("Lat. Inisialisasi Constructor : fareza restu")
    println("---------------------------")
    

    val kucing1 = Kucing("Kitty",2,"Anggora")
    val kucing2 = Kucing("Gembul",1,"Persia")
    val kucing3 = Kucing("Garong",3,"Liar")

    print("${kucing1.nama} bersuara")
    kucing1.suara("Miaww-miaww")

    print("${kucing2.nama} bersuara")
    kucing2.suara("Meongg-meongg")


    print("${kucing3.nama} bersuara")
    kucing3.suara("Roarr-roarr")
}