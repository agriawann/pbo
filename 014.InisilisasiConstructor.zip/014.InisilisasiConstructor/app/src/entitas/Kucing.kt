package app.src.entitas

class Kucing (val  _nama: String, val _usia : Int, val _ras:String) {
    var nama : String; var usia : Int; var ras : String

    init{
        this.nama = _nama
        this.usia = _usia
        this.ras = _ras

        println("Nama : $nama")
        println("Usia : $usia")
        println("Ras :  $ras\n")
    }    

    fun suara(suara:String) = println(suara)
}