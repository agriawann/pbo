package app.src
import app.src.entitas.*

fun main(){
    println("-----------------------------------------")
    println("Lat. Class Bersarang : Fareza")
    println("-----------------------------------------")
   
    val kelasLuar = utama()
    val kelasBersarang = utama.bersarang()

    println( kelasLuar.menyapa() )
    println( kelasBersarang.menyapa() )

}
