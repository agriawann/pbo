package app.src.entitas

class utama {
    var massage="Hallo"
    fun menyapa() = "$massage , ini adalah fungsi adalam class utama"

    class bersarang {
        fun menyapa() = "dan ini adalah fungsi dalam class bersarang"
    }

}
